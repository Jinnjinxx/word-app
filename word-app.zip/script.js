// Full script.js already shown above
// ... Replace this comment with final JavaScript content from earlier output
